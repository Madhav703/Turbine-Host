import discord
from discord.ext import commands
from discord.ext.commands import Context
import humanfriendly
from discord.ext.commands import cooldown
from discord.ext.commands import BucketType
from datetime import datetime
from typing import Union, Optional
from .utils import _self_clean_system, do_removal
import re
from discord import app_commands
import datetime
from humanfriendly import format_timespan
from core.cog import Cog
from .converters import *
import random

class Mod(Cog, name="Moderation", emoji=1018824983251783731):

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        
    @commands.command(
        name="warn"
    )
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    @commands.cooldown(1,5, commands.BucketType.user)
    async def _warn(self, ctx, member: discord.Member, *, reason=None):
        """Someone is breaking Server Rules? Just warn them!"""
        
        reason = reason or "No Reason Provided"
        
        if member.bot:
            return await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.no} You want me to warn my fellow bot friends? what a dumbo!"),allowed_mentions=discord.AllowedMentions.all())
        
        if member.id == ctx.guild.owner.id:
            return await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.no} I can't warn the Server Owner!"),allowed_mentions=discord.AllowedMentions.all())
        
        if member.id == ctx.author.id:
            return await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.no} You can't warn yourself dumbo!"),allowed_mentions=discord.AllowedMentions.all())
        
        if (ctx.author.top_role <= member.top_role):
            embed = discord.Embed(
                description=f'{self.bot.no} {member.mention} has a higher role than you, so you can\'t do this!', color=self.bot.color)
            return await ctx.reply(embed=embed,allowed_mentions=discord.AllowedMentions.all())
        
        if reason:
            await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.yes} {member} has been warned! | {reason}"))
            _e = discord.Embed(color=self.bot.color,title=f"You've been warned in {ctx.guild.name}",timestamp=discord.utils.utcnow())
            _e.add_field(name="Reason",value=reason,inline=False)
            _e.add_field(name="Responsible Moderator",value=f"{ctx.author} (ID: {ctx.author.id})")
            _e.set_thumbnail(url=ctx.guild.icon)
            try:
                await member.send(embed=_e)
            except:
                pass
        
        else:
            _e = discord.Embed(color=self.bot.color,title=f"You've been warned in {ctx.guild.name}",timestamp=discord.utils.utcnow())
            _e.add_field(name="Reason",value=reason,inline=False)
            _e.add_field(name="Responsible Moderator",value=f"{ctx.author} (ID: {ctx.author.id})")
            _e.set_thumbnail(url=ctx.guild.icon)

            try:
                await member.send(embed=_m)
            except:
                pass
            
        
    
    @commands.hybrid_command(
        name="kick",
        help="Kicks the mentioned user with an optional reason!",
    )
    @app_commands.describe(member="Select a member to kick")
    @app_commands.describe(reason="Write an optional reason!")
    @commands.has_guild_permissions(kick_members=True)
    @commands.bot_has_guild_permissions(kick_members=True)
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def kick(self, ctx, member: discord.Member, *, reason=None):

        if (member.id == ctx.guild.me.id):
            return await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.no} I can't kick myself! "),allowed_mentions=discord.AllowedMentions.all())

        if (member.id == ctx.author.id):
            embed = discord.Embed(
                description=f"{self.bot.no} You can't kick yourself", color=self.bot.color)
            return await ctx.reply(embed=embed)
        
        if (ctx.author.top_role <= member.top_role and ctx.author.id != ctx.guild.owner_id):
            embed = discord.Embed(
                description=f'{self.bot.no} You cannot do this action on this user due to role hierarchy.', color=self.bot.color)
            return await ctx.reply(embed=embed)

        if (ctx.guild.me.top_role <= member.top_role):
            embed = discord.Embed(
                description=f'**My Highest Role ({ctx.guild.me.top_role.mention}) is below or equal to **{member.mention}**\'s Highest Role ({member.top_role.mention})**', color=self.bot.color)
            return await ctx.reply(embed=embed)

        if (reason):
            embed = discord.Embed(
                description=f'{self.bot.yes} **{member} was Kicked** | {reason}', color=self.bot.color)
            await ctx.reply(embed=embed)
            x = discord.Embed(
                description=f'**You have been kicked from {ctx.guild.name}**\nReason: {reason}', color=self.bot.color)
            try:
                await member.send(embed=x)
            except:
                pass
            await member.kick(reason=f'Responsible Moderator: {ctx.author} (ID: {ctx.author.id}) - {reason}')
        else:
            embed = discord.Embed(
                description=f'{self.bot.yes} **{member} was Kicked** | No Reason Provided', color=self.bot.color)
            await ctx.reply(embed=embed)
            g = discord.Embed(
                description=f'**You have been kicked from {ctx.guild.name}**', color=self.bot.color)
            try:
                await member.send(embed=g)
            except:
                pass
            await member.kick(reason=f'Responsible Moderator: {ctx.author} (ID: {ctx.author.id})')
     
    @commands.hybrid_command(
        name="ban",
        help="Bans the mentioned user with an optional reason!"

    )
    @commands.has_guild_permissions(ban_members=True)
    @commands.bot_has_guild_permissions(ban_members=True)
    @cooldown(1, 5, BucketType.user)
    @commands.guild_only()
    async def ban(self, ctx, member: discord.Member,*, reason=None):
        NotinGuild = member not in ctx.guild.members

        if (member.id == ctx.guild.me.id):
            return await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.no} I can't ban myself! "),allowed_mentions=discord.AllowedMentions.all())

        if (member.id == ctx.author.id):
            embed = discord.Embed(
                description=f"{self.bot.no} You can't ban Yourself", color=self.bot.color)
            return await ctx.reply(embed=embed)
        

        if not NotinGuild:
            if (ctx.author.top_role <= member.top_role and ctx.author.id != ctx.guild.owner_id):
                embed = discord.Embed(description=f'** You cannot do this action on this user due to role hierarchy.**', colour=self.bot.color)
                return await ctx.reply(embed=embed)

            if (ctx.guild.me.top_role <= member.top_role or member.id == ctx.guild.owner_id):
                embed = discord.Embed(
                description=f'**My Highest Role ({ctx.guild.me.top_role.mention}) is below or equal to **{member.mention}**\'s Highest Role ({member.top_role.mention})**', colour=self.bot.color)
                return await ctx.reply(embed=embed, mention_author=False)

        if (reason):
            embed = discord.Embed(
                description=f'{self.bot.yes} **{member} was Banned** | {reason}', color=self.bot.color)
            await ctx.reply(embed=embed)
            f = discord.Embed(
                description=f'You have been **banned** from **{ctx.guild.name}**\n**Reason : **{reason}', color=self.bot.color)
            try:
                await member.send(embed=f)
            except:
                pass
            await member.ban(reason=f'Responsible Moderator: {ctx.author} (ID: {ctx.author.id}) - {reason}')
        else:
            embed = discord.Embed(
                description=f'{self.bot.yes} **{member} was Banned** | No Reason Provided', color=self.bot.color)
            await ctx.send(embed=embed)
            g = discord.Embed(
                description=f'You have been **banned** from **{ctx.guild.name}**', color=self.bot.color)
            try:
                await member.send(embed=g)
            except:
                pass
            await member.ban(reason=f'Responsible Moderator: {ctx.author} (ID: {ctx.author.id})')
            
    @commands.command()
    @commands.has_permissions(ban_members=True)
    @commands.bot_has_guild_permissions(ban_members=True)
    @commands.cooldown(2, 1, type=commands.BucketType.user)
    async def unban(self, ctx: Context, member: BannedMember, *, reason: ActionReason = None):
        """Unbans a member from the server."""

        if reason is None:
            reason = f"Action done by {ctx.author} (ID: {ctx.author.id})"

        await ctx.guild.unban(member.user, reason=reason)
     
        if member.reason:
            await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.yes} Unbanned {member.user} (ID: {member.user.id}), previously banned for {member.reason}."),allowed_mentions=discord.AllowedMentions.all())
        else:
            await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.yes} Unbanned {member.user} (ID: {member.user.id})."),allowed_mentions=discord.AllowedMentions.all())
           
    @commands.command(aliases=["cleanup"])
    @commands.has_permissions(manage_messages=True)
    @cooldown(1, 5, BucketType.user)
    async def selfclean(self, ctx: Context, search=100):
        """Clean's my messages."""
        
        strategy = _self_clean_system
     
        search = min(max(2, search), 1000)

        spammers = await strategy(ctx, search)
        deleted = sum(spammers.values())
        messages = [
            f'{deleted} message{" was" if deleted == 1 else "s were"} removed.']
        if deleted:
            messages.append("")
            spammers = sorted(spammers.items(),
                              key=lambda t: t[1], reverse=True)
            messages.extend(
                f"- **{author}**: {count}" for author, count in spammers)

        await ctx.send("\n".join(messages), delete_after=5)
    
    @commands.hybrid_group(invoke_without_command=True, aliases=["purge", "clean"], help="An all in one purge command!")
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def clear(self, ctx: Context, Choice: Union[discord.Member, int], amount: int = 5):
        await ctx.defer()
        
        if isinstance(Choice, discord.Member):
            await do_removal(ctx, amount, lambda e: e.author == Choice)

        elif isinstance(Choice, int):
            await do_removal(ctx, Choice, lambda e: not e.pinned)

        await ctx.message.delete()

    @clear.command(name="embeds", aliases=["embed"])
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def embeds(self, ctx, search=100):
        """Removes messages that have embeds in them."""
        await ctx.defer()
        await do_removal(ctx, search, lambda e: len(e.embeds))

    @clear.command()
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def files(self, ctx, search=100):
        """Removes messages that have attachments in them."""
        await ctx.defer()
        await do_removal(ctx, search, lambda e: len(e.attachments))

    @clear.command(name="images", aliases=['image'])
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def images(self, ctx, search=100):
        """Removes messages that have embeds or attachments."""
        await ctx.defer()
        await do_removal(ctx, search, lambda e: len(e.embeds) or len(e.attachments))

    @clear.command(aliases=["sticker"])
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def stickers(self, ctx, search=100):
        """Removes messages that have stickers in them."""
        await ctx.defer()
        await do_removal(ctx, search, lambda e: len(e.stickers))

    @clear.command(name="all")
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def _remove_all(self, ctx, search=100):
        """Removes all messages."""
        await ctx.defer()
        await do_removal(ctx, search, lambda e: not e.pinned)

    @clear.command(name="humans", aliases=["users"])
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def _users(self, ctx, prefix=None, search=100):
        """Removes only user messages. """

        await ctx.defer()
        def predicate(m):
            return m.author.bot is False

        await do_removal(ctx, search, predicate)

    @clear.command()
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    @app_commands.describe(member="Select a Member")
    async def user(self, ctx, member: discord.Member, search=100):
        """Removes all messages by the member."""
        await ctx.defer()
        await do_removal(ctx, search, lambda e: e.author == member)
        
        

    @clear.command(name='startswith',aliases=["startwith"],help="Removes all messages starting with a word/letter")
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def starts_with(self, ctx, *, word: str):
        await ctx.defer()
        await do_removal(ctx, 100, lambda m: m.content.startswith(word))
        
    @clear.command(name='endswith',aliases=["endwith"],help="Removes all messages ending with a word/letter")
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def ends_with(self, ctx, *, word: str):
        await ctx.defer()
        await do_removal(ctx, 100, lambda m: m.content.endswith(word))
        
    @clear.command()
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def contains(self, ctx, *, substr: str):
        """Removes all messages containing a substring.
        The substring must be at least 3 characters long.
        """
        await ctx.defer()
        if len(substr) < 3:
            e = discord.Embed(
                color=self.bot.color, description=f"{self.bot.no} The substring length should be atleast 3 characters.")
            await ctx.reply(embed=e)
        else:
            await do_removal(ctx, 100, lambda e: substr in e.content)

    @clear.command(name="bot", aliases=["bots"])
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def _bot(self, ctx, prefix=None, search=100):
        """Removes a bot user's messages and messages with their optional prefix."""

        await ctx.defer()
        def predicate(m):
            return (m.webhook_id is None and m.author.bot) or (prefix and m.content.startswith(prefix))

        await do_removal(ctx, search, predicate)
        
    @clear.command(name="webhook", aliases=["webhooks"])
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def _webhook(self, ctx, search=100):
        """Removes messages that contains Webhooks."""

        await ctx.defer()
        def predicate(m):
            return (m.webhook_id is not None)

        await do_removal(ctx, search, predicate)
        
    @clear.command(name='links',aliases=['link'])
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def _links(self, ctx, search=100):
        """Removes all messages containing links."""
        await ctx.defer()
        url_regex = re.compile(r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*(),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+")

        def predicate(m):
            return url_regex.search(m.content)

        await do_removal(ctx, search, predicate)
            
    

    @clear.command(name="emoji", aliases=["emojis"])
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def _emoji(self, ctx, search=100):
        """Removes all messages containing custom emoji."""
        await ctx.defer()
        custom_emoji = re.compile(r"<a?:[a-zA-Z0-9\_]+:([0-9]+)>")

        def predicate(m):
            return custom_emoji.search(m.content)

        await do_removal(ctx, search, predicate)

    @clear.command(name="mentions", aliases=['mention'])
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def mentions(self, ctx, search=100):
        """Removes messages that have mentions in them."""
        await ctx.defer()
        await do_removal(ctx, search, lambda e: len(e.mentions) or len(e.role_mentions))

    @clear.command(name="reactions")
    @commands.has_permissions(manage_messages=True)
    @commands.bot_has_permissions(manage_messages=True)
    @commands.guild_only()
    async def _reactions(self, ctx, search=100):
        """Removes all reactions from messages that have them."""
        
        await ctx.defer()
        if search > 2000:
            return await ctx.reply(embed=discord.Embed(color=0x00feff,description=f"Too many messages to search for ({search}/2000)"))

        total_reactions = 0
        async for message in ctx.history(limit=search, before=ctx.message):
            if message.reactions:
                total_reactions += sum(r.count for r in message.reactions)
                await message.clear_reactions()

        await ctx.send(embed=discord.Embed(color=0x00feff,description=f"{self.bot.yes} Successfully removed **{total_reactions}** reactions.", ),delete_after=10)

    @commands.hybrid_command(
        name="timeout",
        aliases=["mute", "stfu"],
        description="Timeouts the mentioned user with an optional reason.",
    )
    @app_commands.describe(member="Select a member")
    @app_commands.describe(duration="Enter time for the timeout, Usage: 2m for 2 minutes etc.")
    @app_commands.describe(reason="Write an optional reason for the timeout!")
    @commands.guild_only()
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def timeout(self, ctx: Context, member: discord.Member, duration, *, reason=None):
        """
        Timeouts a member for specific time.
        """

        if (member.id == ctx.author.id):
            e = discord.Embed(color=self.bot.color,
                              description=f"{self.bot.no} You can't timeout yourself!")
            return await ctx.reply(embed=e)

        if (member.id == ctx.guild.me.id):
            return await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.no} I can't timeout myself! "),allowed_mentions=discord.AllowedMentions.all())

        if (member.id == ctx.guild.owner.id):
            e = discord.Embed(color=self.bot.color,
                              description=f"{self.bot.no} I can't timeout the Server Owner!")
            return await ctx.reply(embed=e)

        if member.guild_permissions.administrator:
            e = discord.Embed(
                color=self.bot.color, description=f"{member} has Administrator perms, so I can't do that!")
            return await ctx.reply(embed=e)

        if (ctx.guild.me.top_role <= member.top_role):
            embed = discord.Embed(
                description=f'**My Highest Role ({ctx.guild.me.top_role.mention}) is below or equal to **{member.mention}**\'s Highest Role ({member.top_role.mention})**', colour=self.bot.color)
            return await ctx.reply(embed=embed)

        if (ctx.author.top_role <= member.top_role):
            embed = discord.Embed(
                description=f'**Your Highest Role ({ctx.author.top_role.mention}) is below or equal to **{member.mention}**\'s Highest Role ({member.top_role.mention})**', colour=self.bot.color)
            return await ctx.reply(embed=embed)

        if reason is None:
            reason = f"Responsible Moderator: {ctx.author} (ID: {ctx.author.id})"
        else:
            reason = f'Responsible Moderator: {ctx.author} (ID: {ctx.author.id}) - {reason}'

        humanly_duration = humanfriendly.parse_timespan(duration)

        await member.timeout(discord.utils.utcnow() + datetime.timedelta(seconds=humanly_duration), reason=reason)

        e = discord.Embed(
            color=self.bot.color, description=f"{self.bot.yes} | **{member} has been timed out for {duration}**")
        await ctx.reply(embed=e)

    @commands.hybrid_command(name="unmute",aliases=["untimeout"],help="Unmutes a muted member")
    @app_commands.describe(member="Select a member")
    @app_commands.describe(reason="Write an optional reason for the unmute")
    @commands.guild_only()
    @commands.has_permissions(moderate_members=True)
    @commands.bot_has_permissions(moderate_members=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def unmute(self, ctx: Context, member: discord.Member, *, reason=None):
        """Removes timeout from a member."""
        
        if not member.is_timed_out():
            return await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.no} {member} isn't muted!"),allowed_mentions=discord.AllowedMentions.all())

        if reason is None:
            reason = f"Responsible Moderator: {ctx.author} (ID: {ctx.author.id})"
        else:
            reason = f"Responsible Moderator: {ctx.author} (ID: {ctx.author.id}) - {reason}"

        await member.timeout(None, reason=reason)
        e = discord.Embed(
            color=self.bot.color, description=f"**{self.bot.yes} | {member} has been unmuted!**")
        await ctx.reply(embed=e)


    @commands.hybrid_group(help="Role management commands")
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.guild_only()
    async def role(self, ctx):
        if ctx.invoked_subcommand is None:
            await ctx.send_help(str(ctx.command)) 
    
    @role.command(name='make', help="Creates a new role in the server",aliases=['create'])
    @cooldown(1, 5, BucketType.user)
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    @app_commands.describe(name="Write a name for the role!")
    async def createrole(self, ctx, *, name):
        guild = ctx.guild
        role = await guild.create_role(name=name, reason=f"Action done by {ctx.author} (ID: {ctx.author.id})")
        embed = discord.Embed(color=self.bot.color,
                              description=f"{self.bot.yes} | Role {role.mention} has been created!")
        async with ctx.typing():
            await ctx.reply(embed=embed)
    
    @role.command(name='delete', help="Deletes a Role")
    @commands.cooldown(1,5, commands.BucketType.user)
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    @app_commands.describe(role="Choose a Role")
    @commands.guild_only()
    async def delete_role(self, ctx, role: discord.Role):
        
        if role.managed:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,description=f"{self.bot.no} {role.mention} is an integrated role, and can't be deleted.")
            )
        if role.is_default():
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,description=f"{self.bot.no} That's a default role and can't be deleted!"))
        if ctx.me.top_role.position <= role.position:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,description=f"The position of {role.mention} is above my top role {ctx.me.top_role.mention}")
            )
        if not ctx.author == ctx.guild.owner and ctx.author.top_role.position <= role.position:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,description=f"The position of {role.mention} is above your top role {ctx.author.top_role.mention}")
            )
        await role.delete()
        async with ctx.typing():
            await ctx.reply(
                embed=discord.Embed(color=self.bot.color,description=f"{self.bot.yes} I've deleted the Role {role.name} `({role.id})`")
            )
    
    @role.command(name="add",help="Adds role to a user",aliases=["give"])
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_guild_permissions(manage_roles=True)
    @commands.cooldown(1,5,commands.BucketType.user)
    @commands.guild_only()
    @app_commands.describe(role="Select a Role" , member="Select a Member")
    async def add(self, ctx, role: discord.Role, member: discord.Member):
        if role.managed:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,
                                    description=f"{self.bot.no} {role.mention} is an Integrated role, and can't be added to users manually!"))
        if role.is_default():
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,
                                    description=f"{self.bot.no} {role.mention} is a default role, try mentioning a real role!"))
        if role in member.roles:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color, 
                                    description=f"{member.mention} already have the {role.mention} role!"))
        if ctx.me.top_role.position <= role.position:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,
                                    description=f"The position of ({role.mention}) is above my highest role ({ctx.me.top_role.mention}), so I can't do this!"))
        if not ctx.author == ctx.guild.owner and ctx.author.top_role.position <= role.position:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,
                                    description=f"The position of ({role.mention}) is above your highest role ({ctx.author.top_role.mention}), so you can't do this!"))
        await member.add_roles(role, reason=f"Responsible Moderator: {ctx.author} (ID: {ctx.author.id})")
        await ctx.reply(
            embed=discord.Embed(color=self.bot.color,
                                description=f"{self.bot.yes} | Added {role.mention} role to {member.mention}"))
        
    
    @role.command(name="remove",help="Removes role from a user",aliases=["take"])
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_guild_permissions(manage_roles=True)
    @commands.cooldown(1,5,commands.BucketType.user)
    @commands.guild_only()
    @app_commands.describe(role="Select a Role" , member="Select a Member")
    async def remove(self, ctx, role: discord.Role, member: discord.Member):
        if role.managed:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,
                                    description=f"{self.bot.no} {role.mention} is an Integrated role, and can't be removed manually!"))
        if role.is_default():
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,
                                    description=f"{self.bot.no} {role.mention} is a default role, try mentioning a real role!"))
        if role not in member.roles:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color, 
                                    description=f"{member.mention} don't have the {role.mention} role!"))
        if ctx.me.top_role.position <= role.position:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,
                                    description=f"The position of ({role.mention}) is above my highest role ({ctx.me.top_role.mention}), so I can't do this!"))
        
        if not ctx.author == ctx.guild.owner and ctx.author.top_role.position <= role.position:
            return await ctx.reply(
                embed=discord.Embed(color=self.bot.color,
                                    description=f"The position of ({role.mention}) is above your highest role ({ctx.author.top_role.mention}), so you can't do this!"))
        await member.remove_roles(role, reason=f"Responsible Moderator: {ctx.author} (ID: {ctx.author.id})")
        await ctx.reply(
            embed=discord.Embed(color=self.bot.color,
                                description=f"{self.bot.yes} | Removed {role.mention} role from {member.mention}"))
        
   
            
            
async def setup(bot):
    await bot.add_cog(Mod(bot))