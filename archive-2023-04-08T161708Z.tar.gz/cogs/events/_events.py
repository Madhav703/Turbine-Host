from __future__ import annotations
import typing
import re
from datetime import datetime
if typing.TYPE_CHECKING:
    from main import Turbine
    
import discord
from core import Context
from core.cog import Cog
from discord.ext import commands


class events(Cog):
    def __init__(self, bot: Turbine):
        self.bot = bot

    @Cog.listener()
    async def on_message_edit(self, message_before, message_after):
        if message_before.guild.id != 983362540543303731:
            return
        channel = self.bot.get_channel(1027075473357946900)
        if not channel:
            return
        if message_before.author.bot:
            return
        if message_before.content == message_after.content:
            return
        if channel:
            embed = discord.Embed(color=0x00ffb3, description=f"Message edited in {message_before.channel.mention} [Jump to Message]({message_before.jump_url})", timestamp=discord.utils.utcnow())
            embed.add_field(name="Before", value=message_before.content, inline=False)
            embed.add_field(name="After", value=message_after.content, inline=False)
            embed.set_author(name=str(message_before.author),icon_url=message_before.author.display_avatar)
            embed.set_footer(text=f"User ID: {message_before.author.id}", icon_url=message_before.author.display_avatar)
            view = discord.ui.View()
            m = discord.ui.Button(url=message_before.jump_url, label="Jump to Message")
            view.add_item(m)
            await channel.send(embed=embed, view=view)
            
    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.guild.id != 983362540543303731:
            return
        channel = self.bot.get_channel(1027075453053321226)
        if message.author.bot:
            return
        if channel:
            _e = discord.Embed(color=0x00ffb3, description=f"Message sent by {message.author} deleted in {message.channel.mention}", timestamp=discord.utils.utcnow())
            _e.add_field(name="__Message__", value=message.content if message.content else "*[Message Unavailable]*", inline=False)
            _e.set_author(name=str(message.author),icon_url=message.author.display_avatar)
            _e.set_footer(text=f"User ID: {message.author.id} | Message ID: {message.id}")
            await channel.send(embed=_e)
            if message.attachments and 'image' in message.attachments[0].content_type:
                d = self.bot.get_channel(1027075573928972329)
                ab = discord.Embed(color=0x00ffb3, description=f"Image sent by {message.author} deleted in {message.channel.mention}",timestamp=discord.utils.utcnow())
                ab.set_image(url=message.attachments[0].proxy_url)
                ab.set_author(name=str(message.author),icon_url=message.author.display_avatar)
                ab.set_footer(text=f"User ID: {message.author.id} | Message ID: {message.id}")
                await d.send(embed=ab)

                

    
    @Cog.listener("on_member_update")
    async def member_nickname_update(self, before, after):
        if before.guild.id != 983362540543303731:
            return
        channel = self.bot.get_channel(1027075929769517127)
        if before.nick == after.nick:
            return
        if channel:
            em = discord.Embed(color=0x00ffb3, title="Nickname Updated",url=f"https://discord.com/users/{after.id}", timestamp=discord.utils.utcnow())
            em.add_field(name="Before", value=before.nick, inline=False)
            em.add_field(name="Now", value=after.nick, inline=False)
            em.set_author(name=str(after), icon_url=after.display_avatar)
            em.set_footer(text=f"User ID: {after.id}")
            await channel.send(embed=em)
    
    @Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.guild.id != 983362540543303731:
            return
        channel = self.bot.get_channel(1027075686109822997)
        a = "Member" if not member.bot else "Bot"
        em = discord.Embed(description=f"A new {a} has joined",color=0x00ffb3,timestamp=discord.utils.utcnow())
        em.add_field(name="Name", value=str(member), inline=False)
        em.add_field(name="ID", value=member.id, inline=False)
        if member.bot:
            async for author in member.guild.audit_logs(limit=1, oldest_first=False, action=discord.AuditLogAction.bot_add):
                members = '{0.user.id}'.format(author)
                user = await self.bot.fetch_user(members)
                em.add_field(name="Added by",value=f'{user} (ID: {user.id})', inline=False)
        em.add_field(name="Created On", value=discord.utils.format_dt(member.created_at, 'F'), inline=False)
        em.set_thumbnail(url=member.display_avatar)
        em.set_author(name=str(member), icon_url=member.display_avatar)
        em.set_footer(text="JOINED", icon_url=member.guild.me.display_avatar)
        await channel.send(embed=em)
        
        ################
        
        if member.guild.id != 983362540543303731:
            return
        ch = self.bot.get_channel(983362540606205988)
        _m = discord.Embed(color=0x00ffb3, timestamp=discord.utils.utcnow())
        _m.description = f"Hey! {member.mention}\nWelcome to {member.guild.name} <a:glowheart:982975092696961034>\n\n<a:turbine_announcement:972475447650689024> Do check out <#983362541046620190> and follow them!\n<a:GirlRainbow:972490751764201542> Take free roles from <#983362541046620199>\n<:HeadAdmin:940808064813113384> Do check out <#983362541046620191>\n\nUser created at: {discord.utils.format_dt(member.created_at, 'F')}\nNow we have {member.guild.member_count} members in the server!<a:seniormanager:941378627075985488><a:seniormanager:941378627075985488>"
        _m.set_thumbnail(url=member.guild.icon)
        _m.set_author(name=str(member), icon_url=member.display_avatar)
        await ch.send(member.mention, embed=_m, allowed_mentions=discord.AllowedMentions.all())

        
    
    @Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        if member.guild.id != 983362540543303731:
            return
        channel = self.bot.get_channel(1027075723384586331)
        if channel:
            type = "member" if not member.bot else "bot"
            em = discord.Embed(description=f"A {type} has left the server",color=0x00ffb3,timestamp=discord.utils.utcnow())
            em.add_field(name="Name", value=str(member), inline=False)
            em.add_field(name="ID", value=member.id, inline=False)
            em.set_thumbnail(url=member.display_avatar)
            em.set_author(name=str(member), icon_url=member.display_avatar)
            em.set_footer(text="LEFT", icon_url=member.guild.me.display_avatar)
            await channel.send(embed=em)
    
    
    @Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, member: discord.User):
        channel = self.bot.get_channel(1027075965253341204)
        if channel:
            em = discord.Embed(description="Member have been banned from the server.",color=0x00ffb3,timestamp=discord.utils.utcnow())
            em.set_thumbnail(url=member.display_avatar)
            em.set_author(name=str(member), icon_url=member.display_avatar)
            em.set_footer(text="BANNED", icon_url=guild.me.display_avatar)
            em.add_field(name="User", value=str(member), inline=False)
            em.add_field(name="Account Created", value=discord.utils.format_dt(member.created_at,'F'), inline=False)
            await channel.send(embed=em)

    @Cog.listener()
    async def on_member_unban(self, guild, member):
        if guild.id != 983362540543303731:
            return
        channel = self.bot.get_channel(1027075998770008084)
        if channel:
            em = discord.Embed(description="Member has been unbanned from the server.",color=0x00ffb3,timestamp=discord.utils.utcnow())
            em.set_thumbnail(url=member.display_avatar)
            em.set_author(name=str(member), icon_url=member.display_avatar)
            em.add_field(name="User",value=str(member))
            async for author in guild.audit_logs(limit=1, oldest_first=False, action=discord.AuditLogAction.unban):
                author = '{0.user.id}'.format(author)
                user = await self.bot.fetch_user(author)
                em.add_field(name="Responsible Moderator",value=f"{user} (ID: {user.id})", inline=False)
            em.set_footer(text="UNBANNED",icon_url=guild.me.display_avatar)
            await channel.send(embed=em)

    @Cog.listener(name="on_member_update")
    async def member_role_update(self, before, after):
        if before.guild.id != 983362540543303731:
            return
        if before.roles != after.roles:
            added = set(after.roles) - set(before.roles)
            removed = set(before.roles) - set(after.roles)
            add = False
            if added:
                added = ' | '.join([a.mention for a in added])
                add = True
            else:
                added = ''
            if removed:
                removed = ' | '.join([a.mention for a in removed])
                add = True
            else:
                removed = ''
            if added:
                ch = self.bot.get_channel(1027075785531592735)
                em = discord.Embed(color=0x00ffb3, description=f"Member ({after.mention}) updated", timestamp=discord.utils.utcnow())
                em.set_author(name=str(after),icon_url=after.display_avatar)
                em.add_field(name="Roles Added", value=added, inline=False)
                em.set_footer(text=f"ID: {after.id}")
                await ch.send(embed=em)
            if removed:
                a = self.bot.get_channel(1027075882604576779)
                am = discord.Embed(color=0x00ffb3, description=f"Member ({after.mention}) updated", timestamp=discord.utils.utcnow())
                am.add_field(name="Roles Removed",value=removed, inline=False)
                am.set_author(name=after, icon_url=after.display_avatar)
                am.set_footer(text=f"ID: {after.id}")
                await a.send(embed=am)

                
    @Cog.listener()
    async def on_guild_role_create(self, role):
        if role.guild.id != 983362540543303731:
            return
        channel = self.bot.get_channel(1027076116453785720)
        if role.is_bot_managed():
            return
        if channel:
            async for author in role.guild.audit_logs(limit=1, oldest_first=False, action=discord.AuditLogAction.role_create):
                member = '{0.user.id}'.format(author)
                user = await self.bot.fetch_user(member)
                em = discord.Embed(description=f"Role {role.mention} created by {user.mention}",color=0x00ffb3,timestamp=discord.utils.utcnow())
                em.add_field(name="Name", value=f"{role.name} (ID: {role.id})", inline=False)
                em.add_field(name="Color", value=str(role.color), inline=False)
                em.add_field(name="Mentionable",value=role.mentionable, inline=False)
                em.add_field(name="Displayed Separately",value=role.hoist, inline=False)
                em.add_field(name="Role Position",value=role.position, inline=False)
                em.set_footer(text="CREATED",icon_url=role.guild.me.display_avatar)
                em.set_author(name=str(user), icon_url=user.display_avatar)
                await channel.send(embed=em)

    
    @Cog.listener()
    async def on_guild_role_delete(self, role):
        if role.guild.id != 983362540543303731:
            return
        channel = self.bot.get_channel(1027076156320657428)
        if channel:
            async for author in role.guild.audit_logs(limit=1, oldest_first=False, action=discord.AuditLogAction.role_delete):
                member = '{0.user.id}'.format(author)
                user = await self.bot.fetch_user(member)
                em = discord.Embed(description=f"Role {role.mention} deleted by {user.mention}",color=0x00ffb3,timestamp=discord.utils.utcnow())
                em.add_field(name="Name", value=f"{role.name} (ID: {role.id})", inline=False)
                em.add_field(name="Color", value=str(role.color), inline=False)
                em.add_field(name="Mentionable",value=role.mentionable, inline=False)
                em.add_field(name="Displayed Separately",value=role.hoist, inline=False)
                em.add_field(name="Role Position",value=role.position, inline=False)
                em.add_field(name='Members', value=len(role.members), inline=False)
                em.set_footer(text="DELETED",icon_url=role.guild.me.display_avatar)
                em.set_author(name=str(user), icon_url=user.display_avatar)
                await channel.send(embed=em)
    
    @Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        #if before.guild.id != 983362540543303731:
            #return
        if before.channel == after.channel:
            return
        if before.channel is None and after.channel is not None:
            join = self.bot.get_channel(1027087662496096337)
            join_embed = discord.Embed(color=0x00ffb3, timestamp=discord.utils.utcnow())
            join_embed.description = f"{member} joined voice channel {after.channel.mention}"
            join_embed.set_author(name=str(member), icon_url=member.display_avatar)
            join_embed.set_footer(text=f"ID: {member.id}")
            await join.send(embed=join_embed)
            
        if before.channel is not None and after.channel is None:
            z = self.bot.get_channel(1027087687112466502)
            leave_embed = discord.Embed(color=0x00ffb3, timestamp=discord.utils.utcnow())
            leave_embed.description = f"{member} left voice channel {before.channel.mention}"
            leave_embed.set_author(name=str(member), icon_url=member.display_avatar)
            leave_embed.set_footer(text=f"ID: {member.id}")
            await z.send(embed=leave_embed)
            
        if before.channel is not None and after.channel is not None and after.channel != before.channel:
            c = self.bot.get_channel(1027087716145442826)
            move_embed = discord.Embed(color=0x00ffb3, timestamp=discord.utils.utcnow())
            move_embed.description = f"{member} switched voice channel {before.channel.mention} ➜ {after.channel.mention}"
            move_embed.set_author(name=str(member), icon_url=member.display_avatar)
            move_embed.set_footer(text=f"ID: {member.id}")
            await c.send(embed=move_embed)
   
    @Cog.listener()
    async def on_guild_channel_create(self, channel):
        if channel.guild.id != 983362540543303731:
            return
        c = self.bot.get_channel(1027076273937326140)
        if not c:
            return
        if str(channel.type) == "stage_voice":
            return
        async for author in channel.guild.audit_logs(limit=1, oldest_first=False, action=discord.AuditLogAction.channel_create):
            member = '{0.user.id}'.format(author)
            user = await self.bot.fetch_user(member)
            embed = discord.Embed(color=0x00ffb3, description=f"New {str(channel.type).title()} Channel ({channel.mention}) created by {user}", timestamp=discord.utils.utcnow())
            embed.add_field(name="Name", value=f"{channel.name} (ID: {channel.id})", inline=False)
            embed.add_field(name="Channel Position",value=channel.position, inline=False)
            if str(channel.type) == "voice":
                bitrate = str(channel.bitrate).replace("000", "")
                embed.add_field(name="Bitrate", value=f"{bitrate} kbps", inline=False)
            if channel.category is not None:
                embed.add_field(name="Category", value=f"{channel.category.name} (ID: {channel.category.id})", inline=False)
            embed.set_footer(text="CREATED", icon_url=channel.guild.me.display_avatar)
            embed.set_author(name=str(user), icon_url=user.display_avatar)
            await c.send(embed=embed)

    @Cog.listener()
    async def on_guild_channel_delete(self, channel):
        if channel.guild.id != 983362540543303731:
            return
        c = self.bot.get_channel(1027087618099388486)
        if not c:
            return
        if str(channel.type) == "stage_voice":
            return
        async for author in channel.guild.audit_logs(limit=1, oldest_first=False, action=discord.AuditLogAction.channel_delete):
            member = '{0.user.id}'.format(author)
            user = await self.bot.fetch_user(member)
            embed = discord.Embed(color=0x00ffb3, description=f"A {str(channel.type).title()} Channel has been deleted by {user}", timestamp=discord.utils.utcnow())
            embed.add_field(name="Name", value=f"{channel.name} (ID: {channel.id})", inline=False)
            embed.add_field(name="Channel Position",value=channel.position, inline=False)
            if str(channel.type) == "voice":
                bitrate = str(channel.bitrate).replace("000", "")
                embed.add_field(name="Bitrate", value=f"{bitrate} kbps", inline=False)
            if channel.category is not None:
                embed.add_field(name="Category", value=f"{channel.category.name} (ID: {channel.category.id})", inline=False)
            embed.set_footer(text="DELETED", icon_url=channel.guild.me.display_avatar)
            embed.set_author(name=str(user), icon_url=user.display_avatar)
            await c.send(embed=embed)
    
    
    @Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot or message.guild is None:
            return
        if re.match(f"^<@!?{self.bot.user.id}>$", message.content):
            ctx: Context = await self.bot.get_context(message)
            self.bot.dispatch("mention", ctx)
    
    @Cog.listener()
    async def on_mention(self, ctx: Context) -> None:
        prefix = "$"
        await ctx.reply(embed=discord.Embed(color=ctx.bot.color,description='Prefix: `$`'),allowed_mentions=discord.AllowedMentions.all())
        

    
    @Cog.listener()
    async def on_command_error(self, ctx: Context, err):

        ignored = (
            commands.CommandNotFound,
            commands.NoPrivateMessage,
            discord.Forbidden,
            discord.NotFound,
        )

        if isinstance(err, ignored):
            return

        if isinstance(err, commands.NotOwner):
            return

        if not hasattr(ctx, "error"):
            ctx.error = ctx.reply


        if isinstance(err, commands.MissingRequiredArgument):
            return await ctx.send_help(str(ctx.command))
        elif isinstance(err, commands.CommandInvokeError):
            await ctx.error(embed=discord.Embed(color=ctx.bot.color, description=f"An error occurred: {err.original}"),allowed_mentions=discord.AllowedMentions.all())

        if isinstance(err, commands.BadArgument):
            if isinstance(err, commands.MessageNotFound):
                return await ctx.error(embed=discord.Embed(color=ctx.bot.color,description="Try the command again, and this time with a real message."))
            if isinstance(err, commands.MemberNotFound):
                return await ctx.error(embed=discord.Embed(color=ctx.bot.color,description="Use the command again, and this time mention a real user."))
            if isinstance(err, commands.ChannelNotFound):
                return await ctx.error(embed=discord.Embed(color=ctx.bot.color,description="Use the command again, and this time mention a real channel/category."))
            if isinstance(err, commands.RoleNotFound):
                await ctx.error(embed=discord.Embed(color=ctx.bot.color,description="Try again and this time use a real role."))
            elif isinstance(err, commands.EmojiNotFound):
                await ctx.error(embed=discord.Embed(color=ctx.bot.color, description="Try again and this time use a real emoji."))
            elif isinstance(err, commands.PartialEmojiConversionFailure):
                await ctx.error(embed=discord.Embed(color=ctx.bot.color,description=f"The argument `{err.argument}` did not match the partial emoji format."))
                
            elif isinstance(err, commands.BadInviteArgument):
                await ctx.error(embed=discord.Embed(color=ctx.bot.color, description=f"The invite that matched that argument was not valid or is expired."))
                
            elif isinstance(err, commands.BadBoolArgument):
                await ctx.error(embed=discord.Embed(color=ctx.bot.color, description=f"The argument `{err.argument}` was not a valid True/False value."))
                
            elif isinstance(err, commands.BadColourArgument):
                await ctx.error(embed=discord.Embed(color=ctx.bot.color, description=f"The argument `{err.argument}` was not a valid colour."))

            else:
                return await ctx.error(embed=discord.Embed(color=ctx.bot.color,description=err))

        elif isinstance(err, commands.MissingRole):
            return await ctx.error(embed=discord.Embed(color=ctx.bot.color, description=f"You need `{err.missing_role}` role to use this command."))

        elif isinstance(err, commands.MaxConcurrencyReached):
            return await ctx.error(embed=discord.Embed(color=ctx.bot.color, description=f"This command is already running in this server. You have wait for it to finish."))

        elif isinstance(err, commands.CommandOnCooldown):
            if await ctx.bot.is_owner(ctx.author):
                return await ctx.reinvoke()
            return await ctx.error(embed=discord.Embed(color=ctx.bot.color,description=f"You are in cooldown, Try again in `{err.retry_after:.2f}` seconds."))

        elif isinstance(err, commands.MissingPermissions):
            permissions = ", ".join(
                [
                    f"{permission.replace('_', ' ').replace('guild', 'server').title()}"
                    for permission in err.missing_permissions
                ]
            )
            await ctx.error(embed=discord.Embed(color=ctx.bot.color, description=f"You lack **`{permissions}`** permissions to run this command."))

        elif isinstance(err, commands.BotMissingPermissions):
            permissions = ", ".join(
                [
                    f"{permission.replace('_', ' ').replace('guild', 'server').title()}"
                    for permission in err.missing_permissions
                ]
            )
            message = f"I'm missing `{permissions}` permissions for this command!"
            try:
                await ctx.error(embed=discord.Embed(color=ctx.bot.color, description=message))
            except discord.Forbidden:
                try:
                    await ctx.author.send(embed=discord.Embed(color=ctx.bot.color,description=f"Hey It looks like, I can't send messages in that channel."))
                except discord.Forbidden:
                    pass

            return

        else:  
            raise 
            
async def setup(bot):
    await bot.add_cog(events(bot))