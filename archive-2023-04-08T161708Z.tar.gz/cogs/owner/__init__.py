import discord
from discord.ext import commands
import requests
from discord.ext.commands import command, cooldown
from discord.ext.commands import Cog, BucketType, Context
import random
from datetime import datetime
from discord.ext.commands import (BadArgument,MissingRequiredArgument,CommandOnCooldown)
from datetime import datetime
import aiohttp
from utilities.paginator import TurbinePaginator 
import io
import inspect
import textwrap
import asyncio 
import subprocess
import traceback
from contextlib import redirect_stdout
import os

class OwnerOnly(commands.Cog,name="Developer"):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._last_result: Optional[Any] = None 
        
    def cleanup_code(self, content: str) -> str:
        if content.startswith('```') and content.endswith('```'):
            return "\n".join(content.split('\n')[1:-1])
        
        return content.strip('`\n')
            
    
    @commands.command(name="eval",help="Evaluates a Code",aliases=["ev"])
    @commands.is_owner()
    @commands.guild_only()
    async def _eval(self, ctx: Context,*, body: str):
        env = {
            'bot': self.bot,
            'ctx': ctx,
            'channel': ctx.channel,
            'author': ctx.author,
            'guild': ctx.guild,
            'message': ctx.message,
            '_': self._last_result,
        }
        
        env.update(globals())
        
        body = self.cleanup_code(body)
        stdout = io.StringIO()
        
        to_compile = f'async def func():\n{textwrap.indent(body, " ")}'
        
        try:
            exec(to_compile, env)
        except Exception as e:
            return await ctx.reply(f'```py\n{e.__class__.__name__}: {e}\n```')
        func = env['func']
        try:
            with redirect_stdout(stdout):
                ret = await func()
        except Exception as e:
            value = stdout.getvalue()
            await ctx.reply(f'```py\n{value}{traceback.format_exc()}\n```')
        else:
            value = stdout.getvalue()
            try:
                await ctx.message.add_reaction(f"{self.bot.yes}")
            except:
                pass
            if ret is None:
                if value:
                    await ctx.reply(f'```py\n{value}\n```')
            else:
                self._last_result = ret
                await ctx.reply(f'```py\n{value}{ret}\n```')
    
    #@commands.group()
    #@commands.is_owner()
    #@commands.guild_only()
    #async def noprefix(self,ctx):
        #"""Adds or removes a user from No Prefix!"""
        #if ctx.invoked_subcommand is None:
            #await ctx.send_help(str(ctx.command))
    
    #@noprefix.command(help="Adds a user for No Prefix")
    #@commands.is_owner()
    #@commands.guild_only()
    #async def add(self,ctx, *,member: discord.Member):
        #try:
            #userdata = {"_id": member.id}
            #if member.id not in userdata:
                #predb.insert_one(userdata)
                #e = discord.Embed(color=self.bot.color,description=f"{self.bot.yes} Added {member} for No Prefix!")
                #await ctx.reply(embed=e)

      #  except pymongo.errors.DuplicateKeyError:
            #r = discord.Embed(color=self.bot.color,description=f"{self.bot.no} {member} is already in No prefix!")
           # await ctx.reply(embed=r)
            
    #@noprefix.command(help="Removes a user from No Prefix")
    #@commands.is_owner()
    #@commands.guild_only()
    #async def remove(self,ctx, *,member: discord.Member):
        #userdata = {"_id": member.id}
        #if member.id not in userdata:
            #predb.delete_one(userdata)
            #e = discord.Embed(color=self.bot.color,description=f"Removed {member} from No prefix!")
            #await ctx.reply(embed=e)

   # @commands.command()
    #@commands.is_owner()
    #async def overrideprefix(self,ctx):

        #for guild in self.bot.guilds:
            #insert_prefix(guild.id, '-')

            #await ctx.send("All servers have their prefixes overridden")

    

    
    #@commands.command(name="serverlist",help="Shows a list of Servers I'm in",aliases=["serverslist"])
    #@commands.is_owner()
    #@commands.guild_only()
    #async def server_list(self,ctx):
        #a = 0
        #p = ChampPaginator(ctx, per_page=10)
        #for i, server in enumerate([a for a in self.bot.guilds],1):
            #p.add_line(f"`{i}.\nServer Name: {server}\nServer ID: {server.id}\nOwner: {str(server.owner)}\nMembers Count: {server.member_count}\n`")
            ##a = a+1
        #p.title=f"List of Servers I'm in ({a})"
        #await p.start()
        
    @commands.command(name="load",help="Loads a Module")
    @commands.guild_only()
    @commands.is_owner()
    async def load(self, ctx: Context,*, module: str):
        try:
            await self.bot.load_extension(module)
        except commands.ExtensionError as e:
            await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{e.__class__.__name__} : {e}"))
        else:
            await ctx.reply(embed=discord.Embed(color=self.bot.color, description=f"{self.bot.yes} Loaded Module: {module}"))
     
    
    @commands.command(name="unload",help="Unloads a Module")
    @commands.is_owner()
    @commands.guild_only()
    async def unload(self, ctx: Context,*, module: str):
        try:
            await self.bot.unload_extension(module)
        except commands.ExtensionError as e:
                   await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{e.__class__.__name__} : {e}"))
        else:
            await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.yes} Unloaded Module: {module}"))
            
    @commands.command(name="reload",help="Reloads a Module!")
    @commands.is_owner()
    @commands.guild_only()
    async def reload(self, ctx: Context,*, module: str):
        try:
            await self.bot.reload_extension(module)
        except commands.ExtensionError as e:
            await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{e.__class.__name__} : {e}"))
        else:
            await ctx.reply(embed=discord.Embed(color=self.bot.color,description=f"{self.bot.yes} Reloaded Module: {module}"))
        
     
        
    @commands.command(help="Change Status of Bot")
    @commands.is_owner()
    async def status(self, ctx, status=None, *, message=None):
        
        message = message or "Turbine Host"
        status = status or 'w'

        if status.startswith('w'):
            await self.bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching , name=message))
            await ctx.message.add_reaction(f'{self.bot.yes}')
        elif status.startswith('p'):
            await self.bot.change_presence(activity=discord.Game(name=message))
            await ctx.message.add_reaction(f'{self.bot.yes}')
        elif status.startswith('l'):
            await self.bot.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name=message))
            await ctx.message.add_reaction(f'{self.bot.yes}')
        elif status.startswith('c'):
            await self.bot.change_presence(activity=discord.Activity(type=discord.ActivityType.competing, name=message))
            await ctx.message.add_reaction(f'{self.bot.yes}')
        else:
            await self.bot.change_presence(activity=discord.Game(name=message))
            await ctx.message.add_reaction(f'{self.bot.yes}')
            
            
    #@commands.command(help="Globally bans any user from all the servers in mutual with the bot.\n Only my developer can use this command!") 
    #@commands.guild_only()
    #@commands.is_owner()
    #async def globalban(self,ctx, user: discord.User):
        #if user.id == 995000644660383764:
            #e = discord.Embed(color=self.bot.color,description="You can't ban my developer!")
            #return await ctx.reply(embed=e,mention_author=False)
        #for guild in self.bot.guilds:
        	#if guild.text_channels[0].permissions_for(guild.me).ban_members:
                	#await guild.ban(user, reason="This User/Bot has been globally banned for possibly (Server Nuking/Raiding, Breaking Discord TOS, Phishing, Mass DMs). For any further query contact the developers in my support server.")
        #await ctx.reply(embed=discord.Embed(color=self.bot.color, description=f"{self.bot.yes} {user} has been global banned!"))
                
                
            
    #@commands.command(name="repeat",help="Repeats a message for X number of times",aliases=["spam"],hidden=True)
    #@commands.is_owner()
    #@commands.guild_only()
    #async def repeat(self, ctx, amount: int,*, message):
        #for i in range(amount):
         #   await ctx.send(message,allowed_mentions=discord.AllowedMentions.all())
            
    #@commands.command(name="restart",help="Restarts the Bot",aliases=["reboot"])
    #@commands.is_owner()
    #@commands.guild_only()
    #async def restart_bot(self, ctx:Context):
        #m = await ctx.reply(embed=discord.Embed(color=self.bot.color, description="Restarting in 5 seconds"))
        #await asyncio.sleep(5)
        #await ctx.message.add_reaction(f"{self.bot.yes}")
        #restart_bot()
        
  #  @commands.command(name="selfrole",aliases=["selfroles"])
    #@commands.is_owner()
    #@commands.guild_only()
    #async def self_role(self, ctx: Context):
       # e = await self.bot.fetch_guild(961899976248672276)
       # if ctx.guild.id != 961899976248672276:
           # _e = discord.Embed(color=self.bot.color,description=f"This command can be used in {e.name} server only!")
           # return await ctx.reply(embed=_e)
        
       # a = discord.Embed(color=self.bot.color, description="Click the button below to get the <@&1062685411312414770> role.",timestamp=discord.utils.utcnow())
        #a.set_author(name=e,icon_url=e.icon)
        #a.set_thumbnail(url=e.icon)
        #a.set_footer(text="To remove the role click the button again!",icon_url=e.icon)
        #await ctx.send(embed=a,view=SelfRoles())
        #await ctx.message.delete()
            
                            
        
    
      
            

async def setup(bot):
    await bot.add_cog(OwnerOnly(bot))