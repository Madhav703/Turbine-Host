from __future__ import annotations
from difflib import get_close_matches
from typing import List, Mapping
import config
import discord
from discord.ext import commands
from utilities.paginator import TurbinePaginator
from core.cog import Cog


class HelpCommand(commands.HelpCommand):
    def __init__(self) -> None:
        super().__init__(
            verify_checks=False,
            command_attrs={
                "aliases": ["h"],
                "cooldown": commands.CooldownMapping.from_cooldown(1, 5.0, commands.BucketType.member),
            },
        )

    async def send_bot_help(self, mapping: Mapping[Cog, List[commands.Command]]):
        ctx = self.context
        prefix = "$"

        hidden = ("Jishaku","Developer")

        embed = discord.Embed(color=ctx.bot.color)
        embed.description = f"**{ctx.bot.dot} My prefix is `{prefix}`\n{ctx.bot.dot} Use `{prefix}help <command | module>` for more info.**"
        embed.set_author(name=str(ctx.author),icon_url=ctx.author.display_avatar)
  

        for cog, cmds in mapping.items():
            if cog and cog.qualified_name not in hidden and await self.filter_commands(cmds, sort=True):
                embed.add_field(
                    inline=False,
                    name=cog.qualified_name.title(),
                    value=", ".join(map(lambda x: f"`{x}`", cog.get_commands())),
                )
                embed.set_footer(text=f"Made with 💚 for {ctx.bot.user.name}",icon_url=ctx.bot.user.display_avatar)

        await ctx.reply(embed=embed)

    async def command_not_found(self, string: str) -> str:
        self.context
        message = f"Couldn't find the `{string}` command."

        commands_list = [str(cmd) for cmd in self.context.bot.walk_commands()]

        if dym := "\n".join(get_close_matches(string, commands_list)):
            message += f"\n\nDid you possibly mean:\n`{dym}`"

        return message

    async def send_command_help(self, command: commands.Command):
        ctx = self.context
        
        embed = discord.Embed(color=ctx.bot.color)
        embed.title = f"Command: {command.qualified_name.capitalize()}"
        embed.set_author(name=command.cog_name.capitalize(
        ) if command.cog_name else f"{self.context.bot.user.name}", icon_url=self.context.bot.user.display_avatar.url)

    
        prefix = "$"

        alias = " | ".join((f"`{alias}`" for alias in command.aliases)
                           ) if command.aliases else "`No aliases`"
        embed.description = (
            f">>> {command.help}\n" if command.help else ''
        )
        embed.add_field(
            name="Usage", value=f"`{prefix}{command.qualified_name} {command.signature}`", inline=False)
        embed.add_field(name="Aliases", value=alias, inline=False)
        

        embed.add_field(
            name="\u200b", value="```yaml\n[] -> optional argument\n<> -> required argument\nDo NOT type these when using commands!\n```")

        embed.set_footer(
            text=f"Requested by {self.context.author}", icon_url=self.context.author.display_avatar.url)
        embed.set_thumbnail(url=self.context.bot.user.display_avatar)

        await self.context.reply(embed=embed)

    async def send_cog_help(self, cog):
        p = TurbinePaginator(self.context, per_page=10)
        a = 0
        ctx = self.context
        prefix = "$"

        for cmd in cog.get_commands():
            if not cmd.hidden:
                brief = "No help provided" if not cmd.short_doc else cmd.short_doc
            p.add_line(
                f"`{prefix}{cmd.qualified_name} {cmd.signature}`\n{brief}\n")
            a += 1
        p.title = f"{cog.qualified_name.title()} [{a}]"
        await p.start()

    async def send_group_help(self, group: commands.Group):
        ctx = self.context
        prefix = "$"

        if not group.commands:
            return await self.send_command_help(group)

        embed = discord.Embed(color=ctx.bot.color)

        embed.set_author(name=group.cog_name.capitalize(
        ) if group.cog_name else f"{self.context.bot.user.name}", icon_url=self.context.bot.user.display_avatar.url)

        embed.title = f"{group.qualified_name.capitalize()}"
        _help = group.help or "No description provided..."

        _cmds = "\n".join(
            f"`{prefix}{c.qualified_name}` : {c.short_doc}" for c in group.commands)

        embed.description = f"> {_help}\n\nSubcommands\n{_cmds}\n"

        embed.set_footer(
            text=f'Use "{prefix}help <command>" for more information.')
        embed.set_thumbnail(url=self.context.bot.user.display_avatar)

        if group.signature:
            embed.add_field(
                name="Usage", value=f"`{group.qualified_name} {group.signature}`", inline=False)

        if group.aliases:
            embed.add_field(name="Aliases", value=" | ".join(
                f"`{aliases}`" for aliases in group.aliases), inline=False)

        await self.context.reply(embed=embed)