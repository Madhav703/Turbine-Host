from ._games import *


async def setup(bot):
    await bot.add_cog(Games(bot))