import discord
from discord_games import button_games
from core.cog import Cog
import discord_games as games
from discord.ext import commands
from discord.ext.commands import cooldown, BucketType
from core import Context 


class Games(Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        
    
    @commands.command(
        name='typerace'
    )
    @commands.guild_only()
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def _typerace(self, ctx: Context):
        """Let's see who's the fastest typer among us!"""
        
        game = games.TypeRacer()
        await game.start(ctx, timeout=45)
    
    

        
        
        
        
        
        
      