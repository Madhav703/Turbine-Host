import asyncio
import contextlib
import re
from concurrent.futures import ThreadPoolExecutor
from functools import partial, wraps
from typing import Optional

import discord
from discord.ext import commands
from PIL import ImageColor

class ChampColor:
    @classmethod
    async def convert(cls, ctx, arg):
        with contextlib.suppress(AttributeError):
            match = re.match(r"\(?(\d+),?\s*(\d+),?\s*(\d+)\)?", arg)
            check = all(0 <= int(x) <= 255 for x in match.groups())

        if match and check:
            return discord.Color.from_rgb([int(i) for i in match.groups()])

        _converter = commands.ColorConverter()
        result = None

        try:
            result = await _converter.convert(ctx, arg)
        except commands.BadColorArgument:
            with contextlib.suppress(ValueError):
                color = ImageColor.getrgb(arg)
                result = discord.Color.from_rgb(*color)

        if result:
            return result

        return await ctx.reply(embed=discord.Embed(color=0x00feff, description=f"`{arg}` isn't a valid color."),delete_after=5,allowed_mentions=discord.AllowedMentions.all())
