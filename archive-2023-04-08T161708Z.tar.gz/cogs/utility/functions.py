import discord
from typing import Union
from discord.ext.commands import Context 
from typing import TYPE_CHECKING, Any,Callable, Generic, Optional, TypeVar, Union
import asyncio
import io
import sys
import os
from contextlib import suppress
import aiohttp
from async_property import async_property

def message_formatter(message:str):
        formated_message = message
        return formated_message

def channel_formatter(channel: int):
        formated_channel = channel
        return formated_channel

def member_formatter(member: discord.Member):
        formated_member = member
        return formated_member

def deltime_formatter(time: str):
        formated_time = time
        return formated_time

def check_member_roles(user: discord.User):
    roles = []
    for role in user.roles:
        if not role.is_default():
            roles.append(role.mention)

    return roles[::-1]

def check_guild_roles(guild: discord.Member):
    roles = []
    for role in guild.roles:
        if not role.is_default() and not role.is_bot_managed():
            roles.append(role.mention)
    return roles[::-1]

def check_member_acknowledgements(member: discord.Member):
    ach = None
    if member.id == 995000644660383764:
        ach = "<a:developer:1019509292820353056> My Developer"
    elif member.guild.owner == member:
        ach = "<:owner:1015528945338294364> Server Owner"
    elif member.guild_permissions.administrator:
        ach = "<:Admin:1018824842843267112> Server Admin"
    elif member.guild_permissions.kick_members or member.guild_permissions.manage_channels or member.guild_permissions.manage_emojis or member.guild_permissions.manage_events or member.guild_permissions.manage_messages or member.guild_permissions.manage_nicknames or member.guild_permissions.manage_permissions or member.guild_permissions.manage_roles or member.guild_permissions.manage_threads or member.guild_permissions.manage_webhooks or member.guild_permissions.mention_everyone:
        ach = "<:mod:1018824983251783731> Server Moderator"
    
    return ach


def check_member_permissions(member: discord.Member):
    perms = []
    if member.guild_permissions.administrator:
        perms.append('Administrator')
    if member.guild_permissions.ban_members:
        perms.append('Ban Members')
    if member.guild_permissions.kick_members:
        perms.append('Kick Members')
    if member.guild_permissions.manage_channels:
        perms.append('Manage Channels')
    if member.guild_permissions.manage_emojis:
        perms.append('Manage Emojis')
    if member.guild_permissions.manage_events:
        perms.append('Manage Events')
    if member.guild_permissions.manage_messages:
        perms.append('Manage Messages')
    if member.guild_permissions.manage_nicknames:
        perms.append('Manage Nicknames')
    if member.guild_permissions.manage_permissions:
        perms.append('Manage Permissions')
    if member.guild_permissions.manage_roles:
        perms.append('Manage Roles')
    if member.guild_permissions.manage_threads:
        perms.append('Manage Threads')
    if member.guild_permissions.manage_webhooks:
        perms.append('Manage Webhooks')
    if member.guild_permissions.mention_everyone:
        perms.append('Mention Everyone')
    if member.guild_permissions.moderate_members:
        perms.append('Moderate Members')

    return perms

    
    return ach

def check_role_perms(role: discord.Role):
    perms = []
    if role.permissions.administrator:
        perms.append('Administrator')
    if role.permissions.ban_members:
        perms.append('Ban Members')
    if role.permissions.kick_members:
        perms.append('Kick Members')
    if role.permissions.manage_channels:
        perms.append('Manage Channels')
    if role.permissions.manage_emojis:
        perms.append('Manage Emojis')
    if role.permissions.manage_events:
        perms.append('Manage Events')
    if role.permissions.manage_messages:
        perms.append('Manage Messages')
    if role.permissions.manage_nicknames:
        perms.append('Manage Nicknames')
    if role.permissions.manage_permissions:
        perms.append('Manage Permissions')
    if role.permissions.manage_roles:
        perms.append('Manage Roles')
    if role.permissions.manage_threads:
        perms.append('Manage Threads')
    if role.permissions.manage_webhooks:
        perms.append('Manage Webhooks')
    if role.permissions.mention_everyone:
        perms.append('Mention Everyone')
    if role.permissions.moderate_members:
        perms.append('Moderate Members')

    return perms

    
    return ach


def check_member_flags(member: Union[discord.Member, discord.User]):
    flags = []
    flag = member.public_flags
    if flag.staff: 
        flags.append("<:melody_staff:1018129802324090930>" )
    if flag.partner: 
        flags.append("<:Partner:1014900453441552444>")
    if flag.hypesquad:
        flags.append("<:hypesquad:1042297320869478401>")
    if flag.bug_hunter:
        flags.append("<:bug_hunter:1018127656992124949>")
    if flag.hypesquad_bravery:
        flags.append("<:HypeSquadBravery:1018126970522968135>")
    if flag.hypesquad_brilliance:
        flags.append("<:HypeSquadBrilliance:1018126863194927125>")
    if flag.hypesquad_balance:
        flags.append("<:HypeSquadBalance:1018126785394774067>")
    if flag.early_supporter:
        flags.append("<:supporter:1018128720550183033>")
    if flag.system or member.system:
        flags.append("<:DISCORD:1018127968582762546>")
    if flag.bug_hunter_level_2:
        flags.append("<:bug_hunter:1018127656992124949>")
    if flag.verified_bot:
        flags.append("<:bot1:1051782313987543121><:bot2:1051782729966043167>")
    if flag.verified_bot_developer:
        flags.append("<:bot_dev:1018127326782947368>")
    if flag.discord_certified_moderator:
        flags.append("<:mod:1050631852878213190>")
    if flag.active_developer:
        flags.append("<:active_developer:1040673241901047839>")
   

    return flags
def get_guild_features(guild: discord.Guild):
    features = []
    for feature in guild.features:
        if len(guild.features) > 15:
            features.append(f"• {feature.replace('_', ' ').title()}")
        else:
            features.append(f"<:tick_yes:1015298407843246160>: {feature.replace('_', ' ').title()}")
    return features

def check_channel_features(channel: discord.channel):
    features = []
    if channel.is_nsfw():
        features.append("<:tick_yes:1015298407843246160>: NSFW Channel")
    if channel.is_news():
        features.append("<:tick_yes:1015298407843246160>: News Channel")
    return features

def check_role_features(role: discord.Role):
    features = []
    if role.mentionable:
        features.append(f"<:tick_yes:1015298407843246160>: Mentionable")
    if role.is_integration(): 
        features.append(f"<:tick_yes:1015298407843246160>: Integration")
    if role.hoist: 
        features.append(f"<:tick_yes:1015298407843246160>: Seperately Displayed")
    if role.is_bot_managed(): 
        features.append(f"<:tick_yes:1015298407843246160>: Bot Role")
    return features


def restart_bot():
    os.execv(sys.executable, ['python'] + sys.argv)

async def get_guild_bans(guild: discord.Guild):
    bannedMembers = []
    async for BannedMember in guild.bans():
        bannedMembers.append(BannedMember)
        
    return bannedMembers

class GuildContext(Context):
    author: discord.Member
    guild: discord.Guild
    
    channel: Union[discord.VoiceChannel,discord.TextChannel,discord.Thread]
    me: discord.Member
    prefix: str 
    
async def success(
    
    self, message: str, delete_after: Union[int, float] = None, **kwargs: Any
) -> Optional[discord.Message]:
    with suppress(discord.HTTPException):
        return await self.reply(
            embed=discord.Embed(
                description=f"{message}",
                color=0xff0000,
            ),
            delete_after=delete_after,
            **kwargs,
        )
    return None
