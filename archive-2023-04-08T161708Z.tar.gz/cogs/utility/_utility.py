import discord
from discord.ext import commands
from discord.ext.commands import Context
from datetime import datetime
import typing
from typing import Union
import unicodedata
import time
from discord.ext.commands import cooldown
from discord.ext.commands import BucketType
from datetime import datetime
from typing import Union
from datetime import datetime, timedelta, timezone
import itertools
from discord import app_commands
from core.cog import Cog
from util.time import *
from .functions import *
from humanfriendly import format_timespan
from collections import Counter
from utilities.paginator import TurbinePaginator
import constants as csts

class Utility(Cog, emoji=1059428539750940722):

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        
    def get_bot_uptime(self, *, brief=False):
        return human_timedelta(self.bot.start_time, accuracy=None, brief=brief, suffix=False)

    
    @commands.command(
        name="say"
    )
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def _say(self, ctx,*, message):
        """Makes the bot say something for you with this command."""
        await ctx.send(message)
        await ctx.message.delete()
    
    
    @commands.hybrid_command(
        name="ping"
    )
    @commands.guild_only()
    @commands.cooldown(1,4, commands.BucketType.user)
    async def _ping(self, ctx: Context):
        """Shows my Ping."""
        
        await ctx.send(f"Pong! {round(self.bot.latency*1000,2)} ms",ephemeral=True)
        
    @commands.hybrid_command(
        name="uptime"
    )
    @commands.cooldown(1,5, commands.BucketType.user)
    @commands.guild_only()
    async def uptime(self,ctx: Context):
        """Shows my uptime"""
        
        await ctx.send(f"**Uptime: {self.get_bot_uptime(brief=False)}**")
        
        
    @commands.hybrid_command(
        name="avatar",
        aliases=["av","pfp"]
    )
    @commands.guild_only()
    @commands.cooldown(1, 6, commands.BucketType.user)
    async def _avatar(self, ctx, member: discord.User=None):
        """Shows any user avatar"""
        
        member = member or ctx.author 
        
        _m = discord.Embed(color=self.bot.color)
        _m.set_author(name=str(member), icon_url=member.display_avatar)
        _m.set_image(url=member.display_avatar)
        _m.set_footer(text=f'Requested by {str(ctx.author)}', icon_url=ctx.author.display_avatar)
        async with ctx.typing():
            await ctx.reply(embed=_m)
            
     
    
    @commands.command(aliases=["whois", "ui"])
    @commands.cooldown(1, 6, commands.BucketType.member)
    async def userinfo(self, ctx: Context, user: Union[discord.Member, discord.User] = None):
        user = user or ctx.author
        NotinGuild = user not in ctx.guild.members
        flags = check_member_flags(user)

        _e = discord.Embed(color=self.bot.color, timestamp=discord.utils.utcnow())
        _e.set_thumbnail(url=user.display_avatar.url)
        b = await self.bot.fetch_user(user.id) 
        if b.banner:
            _e.set_image(url=b.banner.url)
        _e.set_author(name=str(user), icon_url=user.display_avatar.url)

        _e.set_footer(text=f'Requested by {str(ctx.author)}' if not NotinGuild else f'{user} is not in {ctx.guild.name}',icon_url=user.display_avatar if NotinGuild else ctx.author.display_avatar)
        
        _e.add_field(
            name="Nickname" if not NotinGuild and user.nick else "Username",
            value=user.nick if not NotinGuild and user.nick else user.name,
            inline=False,
        )
        _e.add_field(name="ID", value=user.id, inline=True)
        _e.add_field(
            name="Account Created",
            value=f"{discord.utils.format_dt(user.created_at, 'F')} ({discord_timestamp(user.created_at)})",
            inline=False,
        )
        if not NotinGuild:
            _e.add_field(
                name="Server Joined",
                value=f"{discord.utils.format_dt(user.joined_at, 'F')} ({discord_timestamp(user.joined_at)})",
                inline=False,
            )
        if not NotinGuild and user.premium_since:
            _e.add_field(name="Boosting Since", value=discord_timestamp(user.premium_since), inline=False)
        if flags:
            _e.add_field(name="Badges", value=" ".join(flags))
        _e.add_field(name="Avatar", value=f"[Link to Avatar]({user.display_avatar.url})", inline=False)
        if not NotinGuild:
            if user.top_role and not user.top_role.is_default():
                _e.add_field(name="Highest Role", value=user.top_role.mention, inline=False)

            roles = check_member_roles(user)
            if roles:
                _e.add_field(name="Roles",value=f" | ".join(roles) if len(
                roles) < 20 else f'{" | ".join(roles[:20])} and more...',inline=False)
                
            perms = check_member_permissions(user)
            if perms:
                _e.add_field(name="Key Permissions",value=", ".join(perms),inline=False)
                
            ack = check_member_acknowledgements(user) 
            if ack:
                _e.add_field(name='Acknowledgements', value=ack, inline=False) 
                
        async with ctx.typing():
            await ctx.reply(embed=_e) 
                    

    @commands.hybrid_command(
        name="serverinfo",
        aliases=["guildinfo", "si"],
        help="Shows important Server Information"
    )
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def serverinfo(self, ctx: Context):
        guild = ctx.guild

        p = len([a for a in guild.roles if not a.is_default()
                and not a.is_bot_managed()])
        pq = 20
        pqr = p-pq
      
        u = len(
            [a for a in guild.members if a.guild_permissions.administrator and not a.bot])
        v = f"Banned: {len(await get_guild_bans(guild))}" if guild.me.guild_permissions.ban_members else ''
        x = str(guild.default_notifications).replace(
            "NotificationLevel.", " ").replace("_", " ").title()
        y = str(guild.explicit_content_filter).replace("_", " ").title()
        
        zz = guild.premium_subscriber_role.mention if guild.premium_subscriber_role else "None"

        features = get_guild_features(guild)
        roles = check_guild_roles(guild)
        em = discord.Embed(color=self.bot.color,
                           timestamp=discord.utils.utcnow())
        em.set_author(name=f"{guild.name}'s Information", icon_url=guild.icon)
        em.set_footer(
            text=f"Requested by {ctx.author}", icon_url=ctx.author.display_avatar)
        em.add_field(
            name="__About__", value=f'**Name: {guild.name}\nID: {guild.id}\nOwner<:owner:1015528945338294364> : {str(guild.owner)}\nCreated At: {discord.utils.format_dt(guild.created_at,"R")}\nMembers: {guild.member_count}\nAdmins: {u}\n{v}**', inline=False)
        em.add_field(name="__Extras__",value=f'**Verification Level: {str(guild.verification_level).title()}\nUpload Limit: {f"{guild.filesize_limit/1048576}0MB"}\nInactive Channel: {guild.afk_channel if ctx.guild.afk_channel else "None"}\nInactive Timeout: {format_timespan(guild.afk_timeout)}\nExplicit Media Content Filter: {str(guild.explicit_content_filter).replace("_", " ").title()}\nDefault Notifications: {x}\nSystem Channel: {guild.system_channel.mention if guild.system_channel else "None"}\nSystem Messages: {f"{self.bot.yes}" if guild.system_channel_flags.guild_reminder_notifications else f"{self.bot.no}"}\nSystem Welcome Messages: {f"{self.bot.yes}" if guild.system_channel_flags.join_notifications else f"{self.bot.no}"}\nSystem Welcome Messages Reply: {f"{self.bot.yes}" if guild.system_channel_flags.join_notification_replies else f"{self.bot.no}"}\nSystem Boost Messages: {f"{self.bot.yes}" if guild.system_channel_flags.premium_subscriptions else f"{self.bot.no}"}\n2FA Requirement: {f"{self.bot.yes}" if guild.mfa_level else f"{self.bot.no}"}\nBooster Bar: {f"{self.bot.yes}" if guild.premium_progress_bar_enabled else f"{self.bot.no}"}**')
        
        if guild.description:
            em.add_field(name="__Server Description__",
                         value=guild.description, inline=False)

        everyone = guild.default_role
        everyone_perms = everyone.permissions.value

        secret = Counter()
        totals = Counter()
        for channel in guild.channels:
            allow, deny = channel.overwrites_for(everyone).pair()

            perms = discord.Permissions(
                (everyone_perms & ~deny.value) | allow.value)
            channel_type = type(channel)
            totals[channel_type] += 1
            if not perms.read_messages:
                secret[channel_type] += 1
            elif isinstance(channel, discord.VoiceChannel) and (not perms.connect or not perms.speak):
                secret[channel_type] += 1
            elif isinstance(channel, discord.StageChannel) and (not perms.connect or not perms.speak):
                secret[channel_type] += 1

            channel_info = []
            key_to_emoji = {
                discord.TextChannel: f'{self.bot.text}',
                discord.VoiceChannel: f'{self.bot.voice}',
                discord.StageChannel: f'{self.bot.stage}',
            }
            for key, total in totals.items():
                secrets = secret[key]
                try:
                    emoji = key_to_emoji[key]
                except KeyError:
                    continue
                if secrets:
                    channel_info.append(f'{emoji} {total} ({secrets} locked)')
                else:
                    channel_info.append(f'{emoji} {total}')

        em.add_field(name="__Channels Info__",
                     value=f"Total: {len(guild.channels)}\nChannels: {' | '.join(channel_info)}\nRules Channel: {guild.rules_channel.mention if guild.rules_channel else 'None'}", inline=False)

        emoji_stats = Counter()
        for emoji in guild.emojis:
            if emoji.animated:
                emoji_stats['animated'] += 1

                emoji_stats['animated_disabled'] += not emoji.available
            else:
                emoji_stats['regular'] += 1

                emoji_stats['disabled'] += not emoji.available
        fmt = (
            f'Regular: {emoji_stats["regular"]}/{guild.emoji_limit}\n'
            f'Animated: {emoji_stats["animated"]}/{guild.emoji_limit}\n'
        )
        if emoji_stats['disabled'] or emoji_stats['animated_disabled']:
            fmt = f'{fmt}Disabled: {emoji_stats["disabled"]} regular, {emoji_stats["animated_disabled"]} animated\n'
        fmt = f'{fmt}Total Emoji: {len(guild.emojis)}/{guild.emoji_limit*2}'
        em.add_field(name="__Emojis Info__", value=fmt, inline=False)
        if guild.premium_tier != 0:
            boosts = f'Level: {guild.premium_tier} [{self.bot.boosts} {guild.premium_subscription_count} boosts]'
            last_boost = max(
                guild.members, key=lambda m: m.premium_since or guild.created_at)
            if last_boost.premium_since is not None:
                boosts = f'{boosts}\nLast Boost: {last_boost}  ({discord.utils.format_dt(last_boost.premium_since,"R")})\nBooster Role: {zz}'
                em.add_field(name="__Boosts Info__",
                             value=boosts, inline=False)
        em.add_field(name="__Server Features__", value="\n".join(
            features) if features else "No Features", inline=False)
        roles = check_guild_roles(guild)
        if roles:
            em.add_field(name=f"__Server Roles__ ({p})", value=f" | ".join(roles) if len(
                roles) < 20 else f'{f" | ".join(roles[:20])} and {pqr} more...', inline=False)
        if guild.banner:
            em.set_image(url=guild.banner)
        await ctx.reply(embed=em)

    
    
    @commands.hybrid_command(
        name="charinfo",
        aliases=['ci', 'characterinfo']
    )
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def charinfo(self, ctx, *, characters: str):
        """
        Shows you information about a number of characters.
        Only up to 25 characters at a time.
        """

        def to_string(c):
            digit = f"{ord(c):x}"
            name = unicodedata.name(c, "Name not found.")
            return f"`\\U{digit:>08}`: {name} - {c} \N{EM DASH} <http://www.fileformat.info/info/unicode/char/{digit}>"

        msg = "\n".join(map(to_string, characters))
        if len(msg) > 2000:
            a = discord.Embed(color=self.bot.color,
                              description=f"{self.bot.no} Output is too long to display!")
            async with ctx.typing():
                return await ctx.reply(embed=a, mention_author=False)
        async with ctx.typing():
            await ctx.reply(embed=discord.Embed(color=self.bot.color,description=msg))
    
    @commands.hybrid_group(name="list")
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def list(self, ctx):
        if ctx.invoked_subcommand is None:
            await ctx.send_help(str(ctx.command))

    @list.command(name="emojis", help="Shows a list of emojis in the server with their IDs ", aliases=["emoji"])
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def list_emoji(self, ctx):
        if len(ctx.guild.emojis) < 1:
            return await ctx.reply(embed=discord.Embed(color=self.bot.color, description="This server doesn't have any emojis yet!"))

        emojis = ctx.guild.emojis
        p = TurbinePaginator(
            ctx, per_page=10, title=f"List of Emojis in {ctx.guild.name} ({len(emojis)})")
        for i, a in enumerate(emojis, 1):
            p.add_line(f"`[{i:02}]` {str(a)} `{str(a)}`")
        await p.start()

    @list.command(name="roles", help="Shows a list of roles in the server", aliases=["role"])
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    @cooldown(1, 6, BucketType.user)
    async def list_roles(self, ctx):
        if len([a for a in ctx.guild.roles if not a.is_default() and not a.is_bot_managed()]) < 1:
            return await ctx.reply(f"{self.bot.no} No roles found in this Server!\n\nNote: This doesn't show the Bot Roles and the @everyone role!")
        x = 0
        p = TurbinePaginator(ctx, per_page=10)
        for i, roles in enumerate([a for a in ctx.guild.roles if not a.is_default() and not a.is_bot_managed()][::-1], 1):
            p.add_line(
                f"`[{i:02}]` {roles.mention} `[{roles.id}] - {len(roles.members)} members`")
            x += 1
        p.title = f"List of Roles in {ctx.guild.name} ({x})"
        await p.start()

    @list.command(name="admins", help="Shows a list of Admins in the server", aliases=["admin"])
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def list_admins(self, ctx):
        s = 0
        p = TurbinePaginator(ctx, per_page=10)
        for i, admins in enumerate([a for a in ctx.guild.members if a.guild_permissions.administrator and not a.bot], 1):
            p.add_line(f"`[{i:02}]` [{admins}](https://discord.com/users/{admins.id}) `[{admins.id}]`")
            s += 1
        p.title = f"List of Admins in {ctx.guild.name} ({s})"
        await p.start()

    @list.command(name="mods", help="Shows a list of Moderators in the server", aliases=["mod", "moderator", "moderators"])
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def list_mods(self, ctx):
        if len([a for a in ctx.guild.members if a.guild_permissions.manage_messages and not a.guild_permissions.administrator and not a.bot]) < 1:
            return await ctx.reply(embed=discord.Embed(color=self.bot.color, description=f"{self.bot.no} There are no Moderators in this server (Admins and bots aren't included)"))
        a = 0
        p = TurbinePaginator(ctx, per_page=10)
        for i, mods in enumerate([a for a in ctx.guild.members if a.guild_permissions.manage_messages and not a.guild_permissions.administrator and not a.bot], 1):
            p.add_line(f"`[{i:02}]` [{mods}](https://discord.com/users/{mods.id}) `[{mods.id}]`")
            a = a+1
        p.title = f"List of Moderators in {ctx.guild.name} ({a})"
        await p.start()

    @list.command(name="bots", help="Shows a list of bots in the server", aliases=["bot"])
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def list_bots(self, ctx):
        a = 0
        p = TurbinePaginator(ctx, per_page=10)
        for i, bots in enumerate([a for a in ctx.guild.members if a.bot], 1):
            p.add_line(f"`[{i:02}]` [{bots}](https://discord.com/users/{bots.id}) `[{bots.id}]`")
            a = a+1
        p.title = f"List of Bots in {ctx.guild.name} ({a})"
        await p.start()

    @list.command(name="humans", help="Shows a list of Humans (not bots) in the server", aliases=["human", "user", "users","members","member"])
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def list_humans(self, ctx):
        a = 0
        p = TurbinePaginator(ctx, per_page=10)
        for i, human in enumerate([a for a in ctx.guild.members if not a.bot], 1):
            p.add_line(f"`[{i:02}]` {human} `[{human.id}]`")
            a = a+1
        p.title = f"List of Humans in {ctx.guild.name} ({a})"
        await p.start()

    @list.command(name="boosts", help="Shows a list of server boosters in the server", aliases=["boost"])
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def list_boosts(self, ctx):
        if ctx.guild.premium_subscription_count < 1:
            return await ctx.reply(embed=discord.Embed(color=self.bot.color, description=f"{self.bot.no} This server doesn't have any Server boosters!"))
        boosters = ctx.guild.premium_subscribers
        p = TurbinePaginator(
            ctx, per_page=10, title=f"List of Boosters in {ctx.guild.name} ({len(boosters)})")
        for i, a in enumerate(boosters, 1):
            p.add_line(
                f"`[{i:02}]` {a} ({discord.utils.format_dt(a.premium_since,'R')})")
        await p.start()

    @list.command(name='joinpos', help="Shows all members with Join positions in the current server.", aliases=['joinposition'])
    @commands.guild_only()
    @cooldown(1, 6, BucketType.user)
    async def list_joinpos(self, ctx):
        a = 0
        members = sorted(ctx.guild.members,
                         key=lambda m: m.joined_at or ctx.message.created_at)
        p = TurbinePaginator(ctx, per_page=10, timeout=60)
        for x, r in enumerate(members, 1):
            p.add_line(f"`[{x:02}]` {r} `[{r.id}]`")
            a = a+1
        p.title = f'Here are all users with Join position [{a}]'
        await p.start()

    @list.command(name="inrole", help="Shows a list of users in a role")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    @app_commands.describe(role="Choose a role")
    @cooldown(1, 6, BucketType.user)
    async def in_role(self, ctx: commands.Context, *, role: discord.Role):
        if len(role.members) < 1:
            return await ctx.reply(embed=discord.Embed(color=self.bot.color, description=f"{self.bot.no} No members found in {role.mention}"))
        a = 0
        paginator = TurbinePaginator(ctx, per_page=10)
        for i, members in enumerate([a for a in role.members], 1):
            paginator.add_line(f"`[{i:02}]` {members} `[{members.id}]`")
            a += 1
        paginator.title = f"List of Members in {role} ({a})"
        await paginator.start()

    @list.command(name="bans", help="Shows a list of Banned Users of the Server", aliases=["ban"])
    @commands.has_guild_permissions(ban_members=True)
    @commands.bot_has_guild_permissions(ban_members=True)
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def ban_list(self, ctx):
        if len(await get_guild_bans(ctx.guild)) < 1:
            return await ctx.reply(embed=discord.Embed(color=self.bot.color, description=f"{self.bot.no} There are no banned members in this server!"))
        bans = []
        p = TurbinePaginator(ctx, per_page=10, timeout=30)
        async for m in ctx.guild.bans():
            bans.append(m.user)
        for i, x in enumerate(bans, 1):
            p.add_line(f"`[{i:02}]` {x} `[{x.id}]`")
        p.title = f"List of Banned Users in {ctx.guild.name} - [{len(bans)}]"
        await p.start()

    @list.command(name="norole", help="Shows a list of users without a role", aliases=["noroles"])
    @commands.guild_only()
    @cooldown(1, 5, BucketType.user)
    async def list_norole(self, ctx):
        members = [x for x in ctx.guild.members if len(
            x.roles) == 1 and not x.bot]
        if members:
            a = TurbinePaginator(ctx, per_page=10, timeout=30)
            for i, member in enumerate(members, 1):
                a.add_line(f"`[{i:02}]` {member} `[{member.id}]`")
            a.title = f"List of Users without a role - [{len(members)}]"
            await a.start()
        else:
            await ctx.reply(embed=discord.Embed(color=self.bot.color, description=f"{self.bot.no} There are no users without a role in this server!"))

   

    @list.command(name="text",aliases=["channels","channel"])
    @commands.guild_only()
    @commands.cooldown(1,6, BucketType.user) 
    async def _text(self, ctx: Context):
        """Shows a list of Text Channels."""
        z = TurbinePaginator(
            ctx,
            per_page=10,
            timeout=60
        )
        b = 0
        for x, i in enumerate([a for a in ctx.guild.text_channels],1):
            z.add_line(f"`[{x:02}]` {i.mention} `[{i.id}]`")
            b += 1
        z.title = f"List of Text Channels - {b}"
        await z.start()
   
    
    @commands.command(name="chat-gpt",aliases=['openai'])
    @commands.guild_only()
    async def _gpt(self, ctx):
       
        
        await ctx.reply("To access ChatGPT use </chat-gpt:1090243034320478209>",allowed_mentions=discord.AllowedMentions.all())
        
        

        
        
            

async def setup(bot):
    await bot.add_cog(Utility(bot))